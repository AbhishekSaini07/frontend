export interface TaskData {
    taskId: number,
    taskName: string,
    taskDescription: string,
    taskDeadline: string,
    taskStatus: string,
    taskCreatedTime: string,
    taskDoneTime?: string,
    
}
