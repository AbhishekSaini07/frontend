export interface UserData{
    userId: number,
    userName: string,
    name: string,
    email:string,
    imageUrl?:string,
    createdAt: string,
    userDescription: string
}