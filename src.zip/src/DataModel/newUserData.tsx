export interface newUserData {
    userName: string;
    name: string;
    email: string;
    password: string;
    userDescription: string;
   // imageUrl?: string;
}
