export interface NewTaskData {
    taskName: string;
    taskDescription: string;
    taskDeadline: string;
}